package Java.oops.Abstraction;

public class AbstractIphone extends Abstractphone {

	public void turnOn() {
		System.out.println("iPhone Turn ON");
	}

	public void makeCall() {
		System.out.println("iPhone makes a call");
	}

	public void turnOff() {
		System.out.println("iPhone Turn OFF");
	}

}